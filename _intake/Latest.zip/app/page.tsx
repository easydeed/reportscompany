"use client"

import { MarketingHome } from "@/components/marketing-home"

export default function Home() {
  return <MarketingHome />
}
